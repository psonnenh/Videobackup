# Video Respaldo 3.1

App Android que copia los vídeos del almacenamiento interno a la microSD, verifica cada copia con SHA-256 y solo después permite borrar los originales.

Compila automáticamente con GitHub Actions: pestaña **Actions** → **Compilar APK** → último resultado → **Artifacts** → `VideoRespaldo-APK`.
