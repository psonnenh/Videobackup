package com.example.videorespaldo

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.os.storage.StorageManager
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var chooseButton: Button
    private lateinit var copyButton: Button
    private lateinit var deleteButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var details: TextView

    private var destination: DocumentFile? = null
    private var destinationUri: Uri? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var operationRunning = false

    private data class VerifiedVideo(
        val source: File,
        val targetUri: Uri,
        val hash: String,
        val size: Long,
        val modified: Long
    )

    private data class ScanResult(
        val videos: MutableList<File> = mutableListOf(),
        val errors: MutableList<String> = mutableListOf()
    )

    private val verifiedVideos = mutableListOf<VerifiedVideo>()

    private val videoExtensions = setOf(
        "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm",
        "mpeg", "mpg", "m4v", "3gp", "3g2", "ts", "mts",
        "m2ts", "vob", "ogv", "asf", "divx"
    )

    private val blueColor = Color.rgb(35, 145, 255)
    private val prefs by lazy { getSharedPreferences("video_respaldo", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        restoreDestination()
    }

    private fun buildInterface() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            setBackgroundColor(Color.rgb(12, 14, 18))
        }

        val title = TextView(this).apply {
            text = "VIDEO RESPALDO 3.1"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }

        val subtitle = TextView(this).apply {
            text = "COPIA SEGURA • MICROSD"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }

        val info = TextView(this).apply {
            text = "Copia los vídeos del almacenamiento interno a la microSD. " +
                "Cada copia se verifica mediante SHA-256. " +
                "La aplicación nunca borra archivos ni carpetas de la microSD. " +
                "Los originales solo se podrán borrar después de una nueva verificación " +
                "y con autorización expresa de Android."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(4, 8, 4, 18)
        }

        chooseButton = makeButton("1. ELEGIR CARPETA DE LA MICROSD")
        copyButton = makeButton("2. COPIAR Y VERIFICAR VÍDEOS")
        deleteButton = makeButton("3. BORRAR ORIGINALES VERIFICADOS")

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            this.progress = 0
        }

        status = TextView(this).apply {
            text = "Estado: selecciona una carpeta de la microSD"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(4, 18, 4, 8)
        }

        details = TextView(this).apply {
            text = "El destino debe estar en la tarjeta microSD extraíble."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 4, 4, 16)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(info)
        root.addView(chooseButton)
        root.addView(copyButton)
        root.addView(deleteButton)
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 12
        ).apply {
            topMargin = 18
            bottomMargin = 8
        })
        root.addView(status)
        root.addView(details)
        scroll.addView(root)
        setContentView(scroll)

        chooseButton.setOnClickListener { chooseSdFolder() }
        copyButton.setOnClickListener { startCopy() }
        deleteButton.setOnClickListener { confirmDeletion() }
        copyButton.isEnabled = false
        deleteButton.isEnabled = false
    }

    private fun makeButton(label: String): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(blueColor)
            setPadding(12, 14, 12, 14)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 7
                bottomMargin = 7
            }
        }
    }

    private fun chooseSdFolder() {
        if (operationRunning) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        startActivityForResult(intent, REQUEST_TREE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_TREE) {
            if (resultCode != RESULT_OK || data?.data == null) {
                status.text = "Selección de carpeta cancelada"
                return
            }
            val treeUri = data.data!!
            try {
                val flags = data.flags and (
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                contentResolver.takePersistableUriPermission(treeUri, flags)
                val folder = DocumentFile.fromTreeUri(this, treeUri)
                    ?: throw IOException("No se pudo abrir la carpeta seleccionada")

                if (!folder.isDirectory || !folder.canWrite()) {
                    throw IOException("La carpeta no permite escritura")
                }
                if (!isRemovableSdTree(treeUri)) {
                    throw IOException(
                        "La carpeta elegida no pertenece a una microSD extraíble. " +
                            "No se aceptó el destino por seguridad."
                    )
                }

                destination = folder
                destinationUri = treeUri
                prefs.edit().putString(KEY_TREE_URI, treeUri.toString()).apply()
                verifiedVideos.clear()
                status.text = "MICROSD seleccionada correctamente"
                details.text = "Destino: ${folder.name ?: treeUri.lastPathSegment}"
                copyButton.isEnabled = hasStoragePermission()
                deleteButton.isEnabled = false
            } catch (e: Exception) {
                destination = null
                destinationUri = null
                prefs.edit().remove(KEY_TREE_URI).apply()
                status.text = "No se aceptó la carpeta seleccionada"
                details.text = e.message ?: "Error al validar la microSD"
                copyButton.isEnabled = false
                deleteButton.isEnabled = false
            }
        } else if (requestCode == DELETE_REQUEST) {
            if (resultCode == RESULT_OK) {
                finishDeletionCheck(true)
            } else {
                finishDeletionCheck(false)
            }
        }
    }

    private fun restoreDestination() {
        val saved = prefs.getString(KEY_TREE_URI, null) ?: return
        try {
            val uri = Uri.parse(saved)
            val folder = DocumentFile.fromTreeUri(this, uri)
            if (folder != null && folder.isDirectory && folder.canWrite() && isRemovableSdTree(uri)) {
                destination = folder
                destinationUri = uri
                status.text = "MicroSD previamente seleccionada"
                details.text = "Destino: ${folder.name ?: uri.lastPathSegment}"
                copyButton.isEnabled = hasStoragePermission()
            } else {
                clearDestination()
            }
        } catch (_: Exception) {
            clearDestination()
        }
    }

    private fun clearDestination() {
        destination = null
        destinationUri = null
        prefs.edit().remove(KEY_TREE_URI).apply()
        copyButton.isEnabled = false
        deleteButton.isEnabled = false
    }

    private fun isRemovableSdTree(treeUri: Uri): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        return try {
            val documentId = DocumentsContract.getTreeDocumentId(treeUri)
            val volumeId = documentId.substringBefore(':')
            if (volumeId.equals("primary", ignoreCase = true)) return false

            val storageManager = getSystemService(STORAGE_SERVICE) as StorageManager
            storageManager.storageVolumes.any { volume ->
                volume.isRemovable &&
                    !volume.uuid.isNullOrBlank() &&
                    volume.uuid.equals(volumeId, ignoreCase = true)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun hasStoragePermission(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            Environment.isExternalStorageManager()
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            status.text = "Esta versión requiere Android 11 o superior"
            return
        }
        if (!Environment.isExternalStorageManager()) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                status.text = "Concede 'Acceso a todos los archivos' y vuelve a la aplicación"
            } catch (e: Exception) {
                status.text = "No se pudo abrir la configuración de permisos"
                details.text = e.message ?: "Error desconocido"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::copyButton.isInitialized && !operationRunning) {
            copyButton.isEnabled = destination != null && hasStoragePermission()
        }
    }

    private fun setBusy(busy: Boolean) {
        operationRunning = busy
        chooseButton.isEnabled = !busy
        copyButton.isEnabled = !busy && destination != null && hasStoragePermission()
        deleteButton.isEnabled = !busy && verifiedVideos.isNotEmpty()
    }

    private fun startCopy() {
        if (operationRunning) return
        val dest = destination
        val treeUri = destinationUri
        if (dest == null || treeUri == null || !dest.isDirectory || !dest.canWrite() ||
            !isRemovableSdTree(treeUri)
        ) {
            clearDestination()
            status.text = "Selecciona nuevamente una carpeta válida de la microSD"
            return
        }
        if (!hasStoragePermission()) {
            requestStoragePermission()
            return
        }

        setBusy(true)
        progress.progress = 0
        verifiedVideos.clear()
        status.text = "Buscando vídeos en el almacenamiento interno..."
        details.text = "No se modificará ningún archivo de la microSD que ya exista."

        executor.execute {
            try {
                val base = Environment.getExternalStorageDirectory().canonicalFile
                val scanResult = ScanResult()
                scanDirectory(base, base, scanResult)

                val verified = mutableListOf<VerifiedVideo>()
                val errors = mutableListOf<String>()
                var newCopies = 0
                var reusedCopies = 0
                var failed = 0
                val started = SystemClock.elapsedRealtime()

                for ((index, source) in scanResult.videos.withIndex()) {
                    try {
                        val relative = source.parentFile?.canonicalFile
                            ?.relativeTo(base)?.path ?: ""
                        val sourceSize = source.length()
                        val sourceModified = source.lastModified()
                        val sourceHashBefore = sha256File(source)

                        val result = copyOrReuse(source, relative, dest, sourceHashBefore)
                        val sourceHashAfter = sha256File(source)

                        if (source.length() != sourceSize ||
                            source.lastModified() != sourceModified ||
                            sourceHashAfter != sourceHashBefore
                        ) {
                            throw IOException("El original cambió durante la copia; no se habilitó su borrado")
                        }

                        val targetHash = sha256Uri(result.first)
                        if (targetHash != sourceHashAfter) {
                            throw IOException("La verificación SHA-256 no coincide")
                        }

                        verified.add(
                            VerifiedVideo(
                                source = source,
                                targetUri = result.first,
                                hash = sourceHashAfter,
                                size = sourceSize,
                                modified = sourceModified
                            )
                        )
                        if (result.second) newCopies++ else reusedCopies++
                    } catch (e: Exception) {
                        failed++
                        errors.add("${source.name}: ${e.message ?: "Error desconocido"}")
                    }

                    val percent = if (scanResult.videos.isEmpty()) 100
                        else ((index + 1) * 100 / scanResult.videos.size)
                    val elapsed = SystemClock.elapsedRealtime() - started

                    runOnUiThread {
                        progress.progress = percent
                        status.text = "Procesando vídeo ${index + 1}/${scanResult.videos.size}"
                        details.text =
                            "Copias nuevas: $newCopies\n" +
                            "Copias anteriores reutilizadas y verificadas: $reusedCopies\n" +
                            "Verificados: ${verified.size}\n" +
                            "Fallidos: $failed\n" +
                            "Progreso: $percent%\n" +
                            "Tiempo: ${formatTime(elapsed)}"
                    }
                }

                verifiedVideos.clear()
                verifiedVideos.addAll(verified)
                val totalErrors = scanResult.errors.size + errors.size

                runOnUiThread {
                    progress.progress = 100
                    status.text = if (totalErrors == 0 && failed == 0) {
                        "PROCESO FINALIZADO CORRECTAMENTE"
                    } else {
                        "PROCESO TERMINADO CON OBSERVACIONES"
                    }
                    details.text =
                        "Vídeos encontrados: ${scanResult.videos.size}\n" +
                        "Copias nuevas: $newCopies\n" +
                        "Copias existentes reutilizadas y verificadas: $reusedCopies\n" +
                        "Copias verificadas en total: ${verified.size}\n" +
                        "Fallidos: $failed\n" +
                        "Errores de lectura: ${scanResult.errors.size}\n" +
                        "Errores totales: $totalErrors\n\n" +
                        "La microSD no ha tenido archivos ni carpetas borrados.\n" +
                        "Solo los originales verificados pueden solicitarse para borrado."
                    if (errors.isNotEmpty() || scanResult.errors.isNotEmpty()) {
                        details.append(
                            "\n\nDETALLES (máximo 30):\n" +
                                (scanResult.errors + errors).take(30).joinToString("\n")
                        )
                    }
                    setBusy(false)
                    deleteButton.isEnabled = verified.isNotEmpty()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "El proceso se detuvo por un error"
                    details.text = e.message ?: "Error inesperado"
                    setBusy(false)
                    deleteButton.isEnabled = verifiedVideos.isNotEmpty()
                }
            }
        }
    }

    private fun scanDirectory(base: File, dir: File, result: ScanResult) {
        try {
            val canonical = dir.canonicalFile
            val basePath = base.path + File.separator
            if (canonical.path != base.path && !canonical.path.startsWith(basePath)) return
            val children = dir.listFiles()
            if (children == null) {
                result.errors.add("No se pudo leer: ${dir.path}")
                return
            }
            for (file in children) {
                if (file.name.startsWith(".trashed-")) continue
                if (file.isDirectory) {
                    val parentName = file.parentFile?.name
                    if (parentName == "Android" &&
                        (file.name == "data" || file.name == "obb")
                    ) continue
                    scanDirectory(base, file, result)
                } else if (file.isFile &&
                    videoExtensions.contains(file.extension.lowercase(Locale.ROOT))
                ) {
                    result.videos.add(file)
                }
            }
        } catch (e: Exception) {
            result.errors.add("${dir.path}: ${e.message ?: "Error de lectura"}")
        }
    }

    private fun copyOrReuse(
        source: File,
        relativePath: String,
        root: DocumentFile,
        expectedHash: String
    ): Pair<Uri, Boolean> {
        var folder = root
        if (relativePath.isNotBlank()) {
            for (part in relativePath.split(File.separator).filter { it.isNotBlank() }) {
                val matches = folder.listFiles().filter { it.name == part }
                var next: DocumentFile? = when (matches.size) {
                    0 -> null
                    1 -> matches[0]
                    else -> throw IOException("Hay carpetas duplicadas en el destino: $part")
                }
                if (next == null) {
                    next = folder.createDirectory(part)
                        ?: throw IOException("No se pudo crear la carpeta: $part")
                }
                if (!next.isDirectory) throw IOException("Existe un archivo con el nombre de la carpeta: $part")
                folder = next
            }
        }

        val sameName = folder.listFiles().filter { it.name == source.name }
        if (sameName.size > 1) throw IOException("Hay archivos duplicados en el destino: ${source.name}")
        if (sameName.size == 1) {
            val existing = sameName[0]
            if (!existing.isFile) throw IOException("Ya existe una carpeta con el nombre ${source.name}")
            val existingHash = sha256Uri(existing.uri)
            if (existingHash == expectedHash) return Pair(existing.uri, false)
            throw IOException(
                "Ya existe ${source.name} en la SD, pero su contenido es diferente. " +
                    "No se sobrescribió ni se borró."
            )
        }

        val extension = source.extension.lowercase(Locale.ROOT)
        val mime = android.webkit.MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(extension) ?: "application/octet-stream"
        val tempName = ".video_respaldo_${UUID.randomUUID()}.part"
        val temp = folder.createFile(mime, tempName)
            ?: throw IOException("No se pudo crear archivo temporal en la SD")

        contentResolver.openOutputStream(temp.uri, "w")?.use { output ->
            source.inputStream().buffered(BUFFER_SIZE).use { input ->
                output.buffered(BUFFER_SIZE).use { bufferedOutput ->
                    input.copyTo(bufferedOutput, BUFFER_SIZE)
                    bufferedOutput.flush()
                }
            }
        } ?: throw IOException("No se pudo abrir el archivo temporal de la SD")

        val tempHash = sha256Uri(temp.uri)
        if (tempHash != expectedHash) {
            throw IOException("La copia temporal no pasó SHA-256; se conservó sin tocarla")
        }

        if (folder.listFiles().any { it.name == source.name }) {
            throw IOException("Apareció un archivo con ese nombre; no se sobrescribió")
        }
        if (!temp.renameTo(source.name)) {
            throw IOException("La copia se verificó, pero Android no permitió renombrarla")
        }

        val finalMatches = folder.listFiles().filter { it.name == source.name }
        if (finalMatches.size != 1 || !finalMatches[0].isFile) {
            throw IOException("No se pudo localizar de forma única la copia final")
        }
        val finalHash = sha256Uri(finalMatches[0].uri)
        if (finalHash != expectedHash) {
            throw IOException("La copia final no pasó la verificación SHA-256")
        }
        return Pair(finalMatches[0].uri, true)
    }

    private fun sha256File(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(BUFFER_SIZE).use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") {
            "%02x".format(Locale.ROOT, it.toInt() and 0xff)
        }
    }

    private fun sha256Uri(uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(uri)?.buffered(BUFFER_SIZE)?.use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: throw IOException("No se pudo leer la copia de la microSD")
        return digest.digest().joinToString("") {
            "%02x".format(Locale.ROOT, it.toInt() and 0xff)
        }
    }

    private fun formatTime(milliseconds: Long): String {
        val seconds = (milliseconds / 1000).coerceAtLeast(0)
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hours > 0) {
            String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, secs)
        } else {
            String.format(Locale.ROOT, "%02d:%02d", minutes, secs)
        }
    }

    private fun confirmDeletion() {
        if (operationRunning) return
        val count = verifiedVideos.size
        if (count == 0) {
            status.text = "No hay originales verificados para borrar"
            return
        }
        AlertDialog.Builder(this)
            .setTitle("CONFIRMAR BORRADO DE ORIGINALES")
            .setMessage(
                "Hay $count vídeos cuyas copias en la microSD fueron verificadas con SHA-256.\n\n" +
                    "Se volverá a comprobar cada original y cada copia antes de solicitar el borrado.\n\n" +
                    "Android mostrará una segunda autorización. Solo se solicitará borrar los originales " +
                    "del almacenamiento interno. La microSD no se borrará ni modificará.\n\n" +
                    "¿Deseas continuar?"
            )
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("CONTINUAR") { _, _ -> startDeletion() }
            .show()
    }

    private fun startDeletion() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            status.text = "El borrado protegido requiere Android 11 o superior"
            return
        }
        if (operationRunning) return
        val snapshot = verifiedVideos.toList()
        if (snapshot.isEmpty()) return

        val treeUri = destinationUri
        if (treeUri == null || !isRemovableSdTree(treeUri)) {
            status.text = "No se confirmó la microSD; se canceló el borrado por seguridad"
            return
        }

        setBusy(true)
        status.text = "Volviendo a verificar originales y copias..."

        executor.execute {
            val ready = mutableListOf<Uri>()
            val errors = mutableListOf<String>()
            val readyItems = mutableListOf<VerifiedVideo>()

            for (item in snapshot) {
                try {
                    if (!item.source.exists() || !item.source.isFile) {
                        errors.add("${item.source.name}: original no disponible; omitido")
                        continue
                    }
                    if (item.source.length() != item.size ||
                        item.source.lastModified() != item.modified
                    ) {
                        errors.add("${item.source.name}: el original cambió desde la copia; omitido")
                        continue
                    }
                    val originalHash = sha256File(item.source)
                    val destinationHash = sha256Uri(item.targetUri)
                    if (originalHash != item.hash || destinationHash != item.hash) {
                        errors.add("${item.source.name}: SHA-256 no coincide; omitido")
                        continue
                    }
                    val mediaUri = findUniqueMediaUri(item.source)
                    if (mediaUri == null) {
                        errors.add("${item.source.name}: no se encontró una URI única del original; omitido")
                        continue
                    }
                    ready.add(mediaUri)
                    readyItems.add(item)
                } catch (e: Exception) {
                    errors.add("${item.source.name}: ${e.message ?: "Error desconocido"}")
                }
            }

            runOnUiThread {
                if (ready.isEmpty()) {
                    status.text = "No hay originales aptos para borrar"
                    details.text = errors.take(30).joinToString("\n")
                    setBusy(false)
                    deleteButton.isEnabled = verifiedVideos.isNotEmpty()
                    return@runOnUiThread
                }
                try {
                    pendingDeletionItems.clear()
                    pendingDeletionItems.addAll(readyItems)
                    details.text =
                        "Originales que Android puede solicitar borrar: ${ready.size}\n" +
                            "Omitidos por seguridad: ${errors.size}\n" +
                            "Esperando tu autorización de Android...\n\n" +
                            "La carpeta y los archivos de la microSD no forman parte de esta solicitud."
                    val request = MediaStore.createDeleteRequest(contentResolver, ready)
                    startIntentSenderForResult(
                        request.intentSender,
                        DELETE_REQUEST,
                        null,
                        0,
                        0,
                        0
                    )
                    status.text = "Esperando autorización de Android"
                } catch (e: Exception) {
                    status.text = "No se pudo solicitar autorización de borrado"
                    details.text = e.message ?: "Error desconocido"
                    pendingDeletionItems.clear()
                    setBusy(false)
                    deleteButton.isEnabled = verifiedVideos.isNotEmpty()
                }
            }
        }
    }

    private val pendingDeletionItems = mutableListOf<VerifiedVideo>()

    private fun findUniqueMediaUri(file: File): Uri? {
        return try {
            val projection = arrayOf(MediaStore.Video.Media._ID)
            val selection = "${MediaStore.Video.Media.DATA} = ?"
            val args = arrayOf(file.absolutePath)
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                null
            )?.use { cursor ->
                if (!cursor.moveToFirst()) {
                    null
                } else {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                    if (cursor.moveToNext()) null
                    else ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun finishDeletionCheck(approved: Boolean) {
        val requested = pendingDeletionItems.toList()
        pendingDeletionItems.clear()
        if (!approved) {
            setBusy(false)
            status.text = "Borrado cancelado o no autorizado"
            details.text =
                "Android no confirmó la autorización. No se contabilizó ningún original como borrado.\n" +
                    "Las copias de la microSD permanecen intactas."
            deleteButton.isEnabled = verifiedVideos.isNotEmpty()
            return
        }

        setBusy(true)
        status.text = "Comprobando el resultado del borrado..."
        executor.execute {
            val remaining = mutableListOf<VerifiedVideo>()
            var removedCount = 0
            var uncertainCount = 0

            for (item in requested) {
                if (item.source.exists()) {
                    remaining.add(item)
                } else {
                    val parent = item.source.parentFile
                    val parentReadable = parent != null && parent.isDirectory && parent.canRead()
                    val stillListed = if (parentReadable) {
                        parent!!.listFiles()?.any { it.name == item.source.name } ?: true
                    } else {
                        true
                    }
                    if (parentReadable && !stillListed) {
                        val destinationStillValid = try {
                            sha256Uri(item.targetUri) == item.hash
                        } catch (_: Exception) {
                            false
                        }
                        if (destinationStillValid) {
                            removedCount++
                        } else {
                            uncertainCount++
                            remaining.add(item)
                        }
                    } else {
                        uncertainCount++
                        remaining.add(item)
                    }
                }
            }

            val requestedSet = requested.map { it.source.absolutePath }.toSet()
            val notRequested = verifiedVideos.filter { it.source.absolutePath !in requestedSet }
            val finalRemaining = (remaining + notRequested).distinctBy { it.source.absolutePath }
            verifiedVideos.clear()
            verifiedVideos.addAll(finalRemaining)

            runOnUiThread {
                status.text = if (uncertainCount == 0) {
                    "COMPROBACIÓN DE BORRADO TERMINADA"
                } else {
                    "BORRADO TERMINADO CON ARCHIVOS POR COMPROBAR"
                }
                details.text =
                    "Originales cuya eliminación se confirmó: ${removedCount}\n" +
                        "Originales que siguen presentes: ${remaining.size - uncertainCount}\n" +
                        "Resultados inciertos conservados por seguridad: ${uncertainCount}\n\n" +
                        "Las copias de la microSD no se han borrado."
                setBusy(false)
                deleteButton.isEnabled = verifiedVideos.isNotEmpty()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }

    companion object {
        private const val REQUEST_TREE = 1001
        private const val DELETE_REQUEST = 1002
        private const val KEY_TREE_URI = "tree_uri"
        private const val BUFFER_SIZE = 1024 * 1024
    }
}
